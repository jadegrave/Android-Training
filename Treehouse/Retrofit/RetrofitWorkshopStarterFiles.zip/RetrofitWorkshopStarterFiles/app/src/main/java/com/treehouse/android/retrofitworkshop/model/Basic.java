package com.treehouse.android.retrofitworkshop.model;


public class Basic<T> {

    public int status;
    public boolean success;
    public T data;

}
